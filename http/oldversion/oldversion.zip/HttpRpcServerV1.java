package testjavarpc.http.oldversion;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream; 
import java.lang.reflect.Method;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.entity.ContentType;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.reflections.Reflections; 

import testjavarpc.http.tools.Util;
/**
 * 使用 http 重写 rpc
 * @author michazl
 *
 * @param <T>
 */
public class HttpRpcServerV1 extends HttpServlet {
	public static final int broadCastPort = 42226;
	static final String SERVICE_PATH = "/rpc";
	static final int PORT = 64222;
	static final String ARGUMENTS_BASE64 = "argumentsBase64";
	 static final String PARAMETER_TYPES = "parameterBase64";
	 static final String METHOD_NAME = "methodName";
	 static final String CLASS_FULL_NAME = "classFullName";
	 static final String INTERFACE_FULL_NAME = "interfaceFullName";
	/**
	 * 
	 */
	private static final long serialVersionUID = 4388686824109402813L;
	private final Base64.Decoder decoder = Base64.getDecoder();

	private  final Base64.Encoder encoder = Base64.getEncoder();

    public HttpRpcServerV1(List<Package>servicePackages,List<Package>privatePackages,List<Class<?>> filteredClasses) {
    }
    static final HashMap<String, Class<?>> serviceRegistry = new HashMap<>();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	String classFullName = req.getParameter(CLASS_FULL_NAME);
 
        String methodName = req.getParameter(METHOD_NAME);
        Object result = null; 
        try {
    	String parameterBase64 = req.getParameter(PARAMETER_TYPES); 
    	ObjectInputStream parameterInput = new ObjectInputStream(new ByteArrayInputStream(decoder.decode(parameterBase64)));
        Class<?>[] parameterTypes = (Class<?>[]) parameterInput.readObject();
        String argumentsBase64 = req.getParameter(ARGUMENTS_BASE64); 
    	ObjectInputStream argumentsInput = new ObjectInputStream(new ByteArrayInputStream(decoder.decode(argumentsBase64)));
        Object[] arguments = (Object[]) argumentsInput.readObject(); 
       result = getResult(classFullName, methodName, parameterTypes, arguments);
        } catch (Exception e) {	
        	resp.sendError(404, e.getMessage()); 	return;
		}
		resp.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
		resp.setContentType(ContentType.DEFAULT_TEXT.getMimeType());
	         ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream resultOutput = new ObjectOutputStream(baos);  
			resultOutput.writeObject(result);
			String resultBase64 = encoder.encodeToString(baos.toByteArray());
			resp.getWriter().append(resultBase64);
		
    }
    private Object getResult(String classFullName, String methodName, Class<?>[] parameterTypes,Object[] arguments) throws Exception {
    	Object result = null; 
        Class<?> serviceClass = serviceRegistry.get(classFullName);  
        	try { //通过spring bean 提供服务
        		Class<?> claszz = Class.forName("com.ruoyi.common.utils.SpringUtils");
        		Method getBean = claszz.getDeclaredMethod("getBean", new Class[] {String.class});
        		Object springBean = getBean.invoke(claszz, classFullName);
                if ((null!=arguments) && arguments.length > 0)
                {
                    Method method1 = springBean.getClass().getDeclaredMethod(methodName, parameterTypes);
                    result = method1.invoke(springBean, arguments);
                }
                else
                {
                    Method method1 = springBean.getClass().getDeclaredMethod(methodName);
                    result =  method1.invoke(springBean);
                }
        	}catch (Exception e) {
        		e.printStackTrace();
        	}
             if(null == result) {//通过非管理class 创建对象并提供服务。
            	 Class<?> clazz  = null; 
            	 clazz = Class.forName(classFullName); 
     			if(clazz.isInterface()) {//实现接口的类
    	        	 ArrayList<Class<?>> list = Util.getInterfaceImpls(Class.forName(classFullName));
    	        	 if(!list.isEmpty()) {
    	        		 serviceClass = list.get(0);
    	        	 }
            	 }else {
            		 Reflections r  = new Reflections("testjavarpc") ;
            		 Set<?> subs = r.getSubTypesOf(clazz);
            		 if(subs.isEmpty()) {//本体的服务器端版本
            			 serviceClass = clazz;
            		 }else {//子类
                		 Iterator<?> itr = subs.iterator();
                		 while(itr.hasNext()) {
                			 serviceClass = (Class<?>) itr.next();break;
                		 }
            		 }
            	 }
     	         if (serviceClass == null) {
     	             throw  new ClassNotFoundException("impl or subclass of  "+ classFullName + "  not found in class path ");
     	         }
     			 Method method = serviceClass.getMethod(methodName, parameterTypes);
     	         result = method.invoke(clazz.newInstance(), arguments);
             }
            return result;
	}

    public static void main(String[] args) throws Exception {
    	Server server=new Server(PORT);
    	ServletContextHandler handler = new ServletContextHandler(server,"/");
    	handler.addServlet(HttpRpcServerV1.class,HttpRpcServerV1.SERVICE_PATH); 
		server.setHandler(handler);
    	server.start();
//    	server.join();
    	 //广播的实现 :由客户端发出广播，服务器端接收
        //广播地址
        //广播的目的端口
        String message = PORT+SERVICE_PATH;//用于发送的字符串
        try
        {	
        	while(true) {
            DatagramSocket ds = new DatagramSocket();
            DatagramPacket dp = new DatagramPacket(message.getBytes(),message.length(), InetAddress.getByName("255.255.255.255"), broadCastPort);
            ds.send(dp);
            ds.close();
    		Thread.sleep(500);;
        	}
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }
}